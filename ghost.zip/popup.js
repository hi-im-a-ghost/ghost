const orb = document.getElementById('orb')
const statusEl = document.getElementById('status')
const ipEl = document.getElementById('ip')
const modoEl = document.getElementById('modo')
const estadoEl = document.getElementById('estado')

function setConnected(val) {
  orb.classList.toggle('connected', val)
  orb.classList.toggle('disconnected', !val)
  statusEl.textContent = val ? 'Conectado' : 'Desconectado'
  estadoEl.textContent = val ? 'Activo' : 'Inactivo'
  modoEl.textContent = val ? 'Proxy' : '—'
}

async function getIP() {
  try {
    const r = await fetch('https://cloudflare.com/cdn-cgi/trace')
    const text = await r.text()
    const lines = Object.fromEntries(text.trim().split('\n').map(l => l.split('=')))
    ipEl.textContent = lines.ip || '—'
  } catch(e) { ipEl.textContent = '—' }
}

async function init() {
  chrome.runtime.sendMessage({ action: 'status' }, (res) => {
    setConnected(res.connected)
    if (res.connected) getIP()
  })
}

orb.addEventListener('click', () => {
  orb.classList.add('loading')
  orb.disabled = true
  chrome.runtime.sendMessage({ action: 'status' }, (res) => {
    const action = res.connected ? 'disconnect' : 'connect'
    chrome.runtime.sendMessage({ action }, async () => {
      const connected = action === 'connect'
      setConnected(connected)
      if (connected) await getIP()
      else ipEl.textContent = '—'
      orb.classList.remove('loading')
      orb.disabled = false
    })
  })
})

init()
