chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'connect') {
    chrome.privacy.network.webRTCIPHandlingPolicy.set({
      value: 'disable_non_proxied_udp'
    })
    chrome.storage.local.set({ connected: true })
    sendResponse({ ok: true })
    return true
  }
  if (msg.action === 'disconnect') {
    chrome.privacy.network.webRTCIPHandlingPolicy.set({
      value: 'default'
    })
    chrome.storage.local.set({ connected: false })
    sendResponse({ ok: true })
    return true
  }
  if (msg.action === 'status') {
    chrome.storage.local.get('connected', (data) => {
      sendResponse({ connected: !!data.connected })
    })
    return true
  }
})
